# Ksheera Village Milk Co-operative Assignment

## Files
- `milkrate.py` - reusable rate card, payment functions and validation.
- `main.py` - interactive calculator.
- `task2_decimal.py` - Task 2 floating-point demonstration.
- `test_milkrate.py` - automatic tests using `assert`.
- `benchmark.py` - timing comparison for 300, 6,000 and 150,000 payments.

## Run in VS Code terminal
```bash
python task2_decimal.py
python test_milkrate.py
python main.py
python benchmark.py
```

Python 3.10+ recommended. No external libraries are required.

## Assumptions
- Fat is limited to 2.0%–7.0%; SNF is limited to 6.0%–10.0%.
- Litres must be positive.
- Shift is `morning` or `evening`.
- Each 0.1% difference is rounded to the nearest whole step.
- Money is calculated with `Decimal` and rounded to two decimal places.
- During April–June the base rate is Rs. 32.00 and fat step value is Rs. 0.45.
- The seasonal bonus is Rs. 0.50 per litre when ten-day supply exceeds 500 litres.
