"""Small automatic test set."""
from decimal import Decimal
from milkrate import rate_per_litre, payout, ten_day_total, validate_entry

# Expected examples from the assignment
assert rate_per_litre(3.5, 8.5) == Decimal("30.00")
assert rate_per_litre(4.2, 8.7) == Decimal("33.40")
assert payout(8.5, 4.2, 8.7) == Decimal("283.90")
assert payout(12, 3.1, 8.3) == Decimal("333.60")

# Validation checks
assert validate_entry("F01", 10, 3.5, 8.5, "morning")[0] is True
assert validate_entry("F01", -1, 3.5, 8.5, "morning")[0] is False
assert validate_entry("F01", 10, 8.0, 8.5, "morning")[0] is False

# Seasonal rate and bonus threshold example
assert rate_per_litre(3.5, 8.5, "apr_jun") == Decimal("32.00")

sample = [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]
print("Sample ten-day total:", ten_day_total(sample))
print("All tests passed.")
