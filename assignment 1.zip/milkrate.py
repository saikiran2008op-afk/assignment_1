"""Milk payment calculation module."""
from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")
STEP = Decimal("0.1")

# Original rate card
BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")

def money(value):
    """Round a rupee amount to the nearest paisa."""
    return Decimal(str(value)).quantize(CENT, rounding=ROUND_HALF_UP)

def rate_per_litre(fat, snf, season="regular"):
    """Return the price per litre for the selected season."""
    fat, snf = Decimal(str(fat)), Decimal(str(snf))

    if season == "apr_jun":
        base, fat_value, snf_value = Decimal("32.00"), Decimal("0.45"), Decimal("0.30")
    else:
        base, fat_value, snf_value = BASE_RATE, FAT_STEP_VALUE, SNF_STEP_VALUE

    fat_steps = ((fat - Decimal("3.5")) / STEP).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP
    )
    snf_steps = ((snf - Decimal("8.5")) / STEP).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP
    )
    return money(base + fat_steps * fat_value + snf_steps * snf_value)

def payout(litres, fat, snf, season="regular"):
    """Return the payment for one milk entry, rounded to paisa."""
    litres = Decimal(str(litres))
    return money(litres * rate_per_litre(fat, snf, season))

def ten_day_total(entries, season="regular"):
    """Return the total payment for a list of (litres, fat, snf) entries."""
    return money(sum(
        (payout(litres, fat, snf, season) for litres, fat, snf in entries),
        Decimal("0.00")
    ))

def validate_entry(farmer_id, litres, fat, snf, shift):
    """Validate one entry; return (True, message) or (False, message)."""
    try:
        litres, fat, snf = map(Decimal, map(str, (litres, fat, snf)))
    except Exception:
        return False, "Enter valid numeric values."
    if not str(farmer_id).strip():
        return False, "Farmer ID is required."
    if litres <= 0:
        return False, "Litres must be greater than zero."
    if not Decimal("2.0") <= fat <= Decimal("7.0"):
        return False, "Fat must be between 2.0 and 7.0."
    if not Decimal("6.0") <= snf <= Decimal("10.0"):
        return False, "SNF must be between 6.0 and 10.0."
    if shift not in ("morning", "evening"):
        return False, "Shift must be morning or evening."
    return True, "Valid entry."
