"""Task 10: compare float and Decimal totals and execution time."""
from decimal import Decimal
from time import perf_counter

for n in (300, 6000, 150000):
    values = ["33.40"] * n

    start = perf_counter()
    float_total = sum(float(x) for x in values)
    float_time = perf_counter() - start

    start = perf_counter()
    decimal_total = sum((Decimal(x) for x in values), Decimal("0.00"))
    decimal_time = perf_counter() - start

    print(f"{n:>7} payments | float={float_total:.2f} "
          f"({float_time:.6f}s) | Decimal={decimal_total:.2f} "
          f"({decimal_time:.6f}s)")
