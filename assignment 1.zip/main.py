"""Interactive ten-day milk payment calculator."""
from decimal import Decimal
from milkrate import validate_entry, payout, ten_day_total

entries = []
print("Ksheera Milk Co-operative - Payment Calculator")
season = input("Season (regular/apr_jun): ").strip().lower()
if season not in ("regular", "apr_jun"):
    season = "regular"

count = int(input("Number of entries: "))
for i in range(count):
    print(f"\nEntry {i + 1}")
    farmer_id = input("Farmer ID: ").strip()
    litres = input("Litres: ").strip()
    fat = input("Fat %: ").strip()
    snf = input("SNF %: ").strip()
    shift = input("Shift (morning/evening): ").strip().lower()

    valid, message = validate_entry(farmer_id, litres, fat, snf, shift)
    if not valid:
        print("Invalid:", message)
        continue

    entries.append((Decimal(litres), Decimal(fat), Decimal(snf)))
    amount = payout(litres, fat, snf, season)
    print(f"Payment: Rs. {amount:.2f}")

total_litres = sum((row[0] for row in entries), Decimal("0"))
total = ten_day_total(entries, season)

# Seasonal bonus: Rs. 0.50 for every litre if total exceeds 500 litres.
bonus = Decimal("0.00")
if season == "apr_jun" and total_litres > 500:
    bonus = (total_litres * Decimal("0.50")).quantize(Decimal("0.01"))

print("\nTen-day total : Rs.", total)
print("Bonus         : Rs.", bonus)
print("Final payment : Rs.", total + bonus)
